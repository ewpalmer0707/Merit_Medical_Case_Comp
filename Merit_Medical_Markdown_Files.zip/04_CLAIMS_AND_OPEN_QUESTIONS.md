# Claims register — conversation, repository, and evidence

As of October 24, 2026. This records what can be stated, what was proposed, and what remains unresolved. It supplements rather than replaces the existing research. A source being linked elsewhere in the repo does not mean every inference drawn from it has been confirmed.

Status meanings: **case/rubric** = provided competition materials; **primary checked** = inspected in this conversation or this upload; **proposal/assumption** = a team or assistant design choice; **unverified here** = appears in the meeting or existing repo but not independently established by this handoff.

## Competition and company facts

| Claim | Status and accurate treatment |
|---|---|
| Pilot must start in 2026, so the entire solution must be short-term | **Case/rubric:** the pilot must be launchable in 2026; multi-year scaling is permitted. |
| Margin target is 22–25%, possibly by 2030 | **Corrected by case:** 20–22% non-GAAP operating margin in 2026. |
| The $400M target is one year's cash flow or a program budget | **Corrected by case:** cumulative free cash flow over the three-year CGI program ending December 31, 2026. No supplier-program budget is specified. |
| Merit has $477M and therefore $77M available for this plan | **Unverified here:** period, metric, source, and available-budget conclusion were not established in the meeting. See the primary cash-flow note below. |
| Most of the top 78 have completed EcoVadis; 50% or 85% is known | **Assumption:** the case says large suppliers generally completed quickly, but provides no completion count for the top 78. Neither percentage is measured Merit data. |
| The other suppliers number 900 | **Arithmetic:** approximately 1,030 minus 78 is approximately 952; actual segmentation can overlap a spend ranking. |
| All top-78 suppliers are American, sole-source, or equally ready | **Unsupported:** spend concentration does not establish geography, criticality, or readiness. |
| High power means only sole-source status | **Case:** Exhibit 3 also includes high spend. Readiness and power are different dimensions. |
| Low spend means low importance or easy replacement | **Unsupported:** low-spend components can still be critical and difficult to replace. |
| Incomplete reporting proves a supplier pollutes heavily or exploits workers | **Unsupported:** the case describes capacity and documentation barriers; nonresponse does not establish the underlying performance. |
| Merit's awards are false | **Contrary to case framing:** the case calls them independently earned; it asks Merit to avoid overstating what its evidence supports. |
| The task is solely to lower carbon emissions | **Incomplete:** the brief includes worker outcomes, relationships, continuity, broader sustainability information, costs, and public communication. |
| Adjusted rubric weights are inaccessible | **Resolved by repo:** 25/25/15/15/10/10. See the [requirements file](02_COMPETITION_REQUIREMENTS.md). |

## Emissions discrepancy: now checked against Merit's report

**Primary checked:** [Merit 2025 Sustainability Report](https://www.merit.com/wp-content/uploads/2026/06/Merit-Medical-Sustainability-Report_2025.v17.pdf), printed pp. 7 and 16–17.

The report states that refrigerants were added to the 2020 and 2025 inventories during rebaselining, but 2024 refrigerants were not recalculated. Its table labels 2025 combined Scope 1+2 emissions as **2% below the 2020 baseline**. Therefore, the raw 2024-to-2025 difference is not a comparable operational increase. The case's "rose 2%" wording is not the same as the report's baseline comparison. The meeting's specific 2023-to-2025/1.7% explanation was not established by this report passage.

The earlier chat correctly flagged the case's inconsistency but had not then read this primary-source explanation. This note supersedes the unresolved status for the refrigerant issue.

## Cash-flow note

The same report's printed p. 7 lists free cash flow of **$185.659M for 2024** and **$215.655M for 2025**. Their sum is **$401.314M [calculation]** before adding any 2026 figure. The existing repo's approximately $401.4M results from summing rounded inputs. This is not the same as cash on hand or an approved budget. The meeting's approximately $477M could concern another reporting period; verify its source before interpreting it.

## Supplier program, technology, and partner claims

| Claim discussed | Status and boundary |
|---|---|
| Every successful buyer used the same approach; mandates/audits always fail | **Overgeneralization:** the repo contains case examples, not evidence that every case succeeded or a controlled causal comparison. Retain counterexamples and differences. |
| Schneider used exactly three groups based on document literacy | **Partly supported:** maturity-based engagement is documented. The precise three spoken descriptions were not verified by the primary pages checked in this chat. Existing research cites additional secondary material. |
| Training always raises supplier margins | **Unsupported as a universal claim:** efficiency can produce savings, but examples do not establish typical net returns after all costs. |
| Helping suppliers reduce Scope 1+2 automatically reduces Merit's Scope 3 by the same total | **Incorrect attribution:** the portion associated with goods/services supplied to Merit must be accounted for; do not assign all company-wide supplier reductions to Merit. See [GHG Protocol](https://ghgptechassistance.zendesk.com/hc/en-us/articles/37916158806804-What-are-the-minimum-and-optional-boundaries-of-each-scope-3-category). |
| EcoVadis is only a supplier grading itself | **Corrected:** expert review of supporting evidence is part of the rating methodology. See [EcoVadis](https://resources.ecovadis.com/ecovadis-solution-materials/csr-rating-methodology-scoring-principles). |
| Any existing EcoVadis, CDP, or SMETA result is equivalent | **Unsupported:** the instruments differ in purpose, coverage, scope, timing, and assurance. Sharing an existing result does not establish equivalence. |
| Vitals takes 30 minutes, so the entire supplier process takes 30 minutes | **Primary checked with limit:** EcoVadis says its questions should take at most 30 minutes; this is not a guarantee for onboarding, finding evidence, translating records, or measuring a carbon footprint. Some evidence uploads are optional; other questions are declarative. |
| An invitation means a full EcoVadis rating is free | **Not established:** distinguish Vitals, Ratings, subscription, buyer licensing, sponsorship, and consulting. The invitation alone does not settle who pays or the cost. |
| Prefilling from spend establishes verified supplier emissions | **Unsupported:** an estimate needs a method and label. Supplier-specific measurements, allocations, estimates, corrections, and evidence must remain distinguishable. |
| One Tijuana employee can absorb the coaching role | **Proposal:** no role capacity, qualifications, workload, backfill cost, or management commitment was confirmed. |
| Merit has approximately 2,000 employees in Tijuana and no plant in China | **Unverified here:** statements in discussion/repo require dated corporate evidence and a precise definition of presence. Neither establishes available coaching capacity. |
| Local Chinese consultants are cheaper than travel | **Unverified here:** no comparable scope, bids, rates, travel costs, or language/industry qualification was established. |
| AI can neutrally verify supplier sustainability from company data | **Proposal:** data access, completeness, validation, error handling, human review, and evidence provenance are untested. No AI system was selected. |
| Proposed tier sizes, thresholds, minimum scores, timelines, and $0.5–0.7M budget are facts | **Proposal/assumption:** these are design or costing estimates in the existing recommendation, not Merit-approved numbers or supplier quotes. |

Vitals source: [official process guide](https://support.ecovadis.com/hc/en-us/articles/14962857786642-What-is-the-EcoVadis-Vitals-process). The handoff did not verify a product price or purchaser arrangement.

## Mexico: the identified program exists; access for Merit is unconfirmed

**Primary checked:** [IFC / INA / Secretaría de Economía release, August 4, 2025](https://www.ifc.org/es/pressroom/2025/ifc-ina-y-la-secretar-a-de-econom-a-anuncian-nueva-fase-del-programa-de-desarrollo).

The release confirms the agreement and a program centered on automotive supply chains: anchor-company needs, supplier capability diagnostics, training, mentoring, consulting, and links to financing. It states no cost for participating companies. That does **not** establish that Merit or medical-device suppliers are accepted, that an ESG/EcoVadis curriculum exists, or that places and consultants are currently available. A proposal to extend the model to medtech remains a proposal.

Before claiming it as a ready implementation partner, the unresolved questions are eligibility, curriculum, current intake, location, capacity, language, timing, cost allocation, and whether an anchor medtech company can participate. No outreach was performed in this upload.

## China: identify the database accurately

**Primary checked:** [IPE's own description](https://wwwen.ipe.org.cn/about/about.aspx).

IPE is a Beijing-based nonprofit environmental research organization. Blue Map integrates government and corporate environmental information. It is not accurately described simply as a Chinese government-operated database. A record screen does not establish a full supplier carbon inventory, comprehensive labor assurance, or the absence of violations. Product functions, coverage, match quality, and any service charges require checking for the proposed use.

The existing repo makes additional China-related regulatory and countermeasure claims. Those were not independently reverified in this upload; do not treat this handoff as legal confirmation of them.

## Incentives and financial modeling questions from the meeting

- Earlier payment: who funds the timing difference, for which invoices, by how many days, under what financing/discount terms, and with what cash-flow effect? The invoice's face value alone does not answer program cost.
- Longer contracts or volume commitments: what price, flexibility, quality conditions, and obligations would each side accept? Bank financing eligibility was not established.
- Administrative staffing: no evidence was supplied that faster payments necessarily require more accountants.
- ROI: identify whose savings are counted, when they occur, what costs they require, and whether the result is projected, realized, or attributable to the intervention.

These are open analysis questions, not approved incentives or new financial estimates.

## Status items for collaborators

- Verify the final team name, slot, required signup fields, and team number against the organizer sheets. The existing README's historical slot record was not reopened here.
- Confirm named owners for the large-supplier/Mexico/China research split and record any outcomes from the planned Monday, October 26 meeting. No subsequent meeting outcome was supplied in this conversation.
- Preserve dated source distinctions: response rates, rated-spend coverage, science-based-target commitments, operational intensity reductions, and absolute emissions reductions are different measures.
- Keep the strategy open to contradictory evidence. The meeting explicitly deferred final selection.
