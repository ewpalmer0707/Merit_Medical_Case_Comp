# Primary-source benchmarks checked in Cameron's conversation

Checked October 24, 2026. These notes describe company programs, not a recommendation already adopted by the team. Results are company-reported unless a specific assurance scope is identified. A successful example does not demonstrate that every supplier, sector, or country will obtain the same result.

## Philips — differentiate support by supplier maturity

Philips uses annual supplier self-assessments validated by its experts. Its four categories are Best in Class, Supplier Sustainability Improvement Plan, Do It Yourself, and Potential Zero Tolerance. Engagement varies: strong performers have annual self-assessments, while suppliers needing improvement receive deeper assessment and tailored support. The program covers environment, safety, ethics, labor, and human rights.

Primary source: [Supplier sustainability performance](https://www.philips.com/a-w/about/sustainability/supplier-sustainability/supplier-sustainability-performance.html). This supports maturity-based engagement, not the claim that audits are always unnecessary.

### Reporting participation and implementation assistance

Philips' 2024 annual report states that its CDP engagement program included 504 of its largest suppliers with an 88% response rate. It also reports 22 on-site assessments producing tailored improvement plans; its team estimates the cost and return of identified energy-efficiency measures. A response rate is not a verified emissions-reduction rate.

Primary source: [2024 annual report, supplier decarbonization section, printed pp. 233–234](https://www.sec.gov/Archives/edgar/data/313216/000031321625000012/a2024-philipsannualrepor.htm).

### Specific Chinese supplier example

Zhejiang Haishun joined Philips' program in 2020. The companies identified more than 120 improvement opportunities. Philips' December 2021 article describes projected annual electricity savings above 350,000 kWh, projected water savings around nine million liters, and anticipated wastewater-quality improvements. Equipment and process measures included injection-molding heaters and air compressors. The article's body presents projections, not independently verified realized savings. Haishun supplied accessories for personal-care products; it is not a demonstrated medical-device component example.

Primary source: [Philips and Haishun, December 8, 2021](https://www.usa.philips.com/a-w/about/news/archive/standard/news/articles/2021/20211208-philips-sustainability-program-puts-collaboration-ahead-of-auditing-to-reduce-supply-chain-co2-emissions.html).

## Medtronic — modular measurement and decarbonization support

Medtronic's public playbook organizes supplier work into calculating emissions, setting science-based targets, reporting annually, and implementing reductions. It provides guides, a dedicated support contact, webinars, and forums, with modules suited to suppliers' maturity. It asks suppliers to calculate or estimate annual emissions using credible methods and identifies CDP or Watershed as reporting channels.

Primary sources: [Supplier Decarbonization Executive Summary](https://www.medtronic.com/content/dam/medtronic-wide/public/united-states/customer-support-services/distributor-resources/supplier-decarbonization-executive-summary.pdf), particularly PDF pp. 4–6; [Supplier Standards and Policies](https://www.medtronic.com/en-us/our-company/governance/suppliers/supplier-standards-policies.html).

Limits: these documents do not establish a per-supplier cost, an SME completion rate, or program ROI. Older assessment-coverage figures in the team's existing research concern different reporting periods and potentially different programs.

## Johnson & Johnson — assessment, monitoring, and disclosure

J&J's supplier page describes formal assessments and audits to monitor its Responsibility Standards. Suppliers in its sustainability program must complete EcoVadis assessments and work on improvements. It also requests environmental disclosure through CDP from certain suppliers. This is evidence of distinct mechanisms for sustainability assessment, monitoring, and environmental reporting.

Primary source: [Supplier sustainability](https://www.jnj.com/suppliers/sustainability).

Limits: the cited page does not establish supplier-program cost. Do not mix historical CDP participation with later platform changes or assume all suppliers are covered. Some older annual-report URLs redirected during retrieval; historical counts from inaccessible reports were not added here as newly verified results.

## Patagonia — funding assistance and remediation

Patagonia describes paying partly or fully for factory training and improvement programs, using staff or local consultants to investigate root causes, recognizing industry tools and certifications, and maintaining differentiated monitoring for strong performers. Separately, it states that it finances supplier energy and carbon audits addressing energy efficiency, renewable energy, and carbon-intensive fuels.

Primary sources: [Working With Factories](https://www.patagonia.com/our-footprint/working-with-factories.html); [Help Suppliers Cut Emissions](https://www.patagonia.com/our-supply-chain.html).

Limits: apparel is a different industry. These pages do not supply a cost estimate that can be transferred directly to Merit or prove that assistance eliminates all supplier burden.

## Schneider Electric — the Zero Carbon Project identified by Nolan

Schneider launched the project in 2021 with approximately 1,000 selected suppliers. Its published roadmap is Analytics, Ambition, Action: establish a footprint and hotspots, set goals, and implement a roadmap. It supplies training, tools, expert support, and peer learning. The program page documents eight technical webinars and more than 1,300 supplier participants trained.

Primary source: [Zero Carbon Project](https://www.se.com/ww/en/about-us/sustainability/zero-carbon-project/).

### Evidence about starting from low capability

Schneider reports helping more than 700 organizations calculate their carbon footprint for the first time and having 950 participating suppliers publicly disclose emissions by the end of 2024. These are capability/disclosure measures; they do not themselves demonstrate verified reductions or identify an SME-only subgroup.

Primary source: [Unlocking the power of collaboration, July 18, 2025](https://www.se.com/ww/en/insights/sustainability/technology-and-innovation/unlocking-the-power-of-collaboration-three-strategies-for-a-sustainable-supply-chain-with-your-suppliers/).

### Keep the reduction metric precise

Schneider's November 7, 2025 article reports a 53% average reduction in operational emissions intensity as of September 2025. This is a dated supplier-program intensity result, not a 53% reduction of Schneider's entire absolute Scope 3 inventory. The same article discusses segmentation by climate maturity and emissions impact; those axes are not identical to Merit's supplier criticality/readiness axes.

Primary source: [The essentials for value chain decarbonization](https://blog.se.com/sustainability/2025/11/07/the-essentials-for-value-chain-decarbonization/).

The existing repo also cites a later 56% result. That later figure is not automatically contradicted by the earlier 53%; retain each date, denominator, method, and source. Its later primary report was not independently rechecked for this upload.

### Financial benefit example shared within the supplier community

Schneider's May 2022 case study describes Henkel sharing its existing efficiency experience with participating suppliers, including a digital system associated with reported annual savings of EUR 8 million. These are Henkel's reported savings, not savings demonstrated to have been caused by joining the Zero Carbon Project, nor a typical result for small suppliers.

Primary source: [The Zero Carbon Project Highlights Henkel's Decarbonization Program](https://perspectives.se.com/case-study/schneider-electric-and-henkel-collaborate-to-accelerate-decarbonization-across-the-supply-chain).

## Standards and evidence definitions checked

- [GHG Protocol scope definitions](https://ghgptechassistance.zendesk.com/hc/en-us/articles/27680240285460-How-does-the-GHG-Protocol-define-and-categorize-emissions): owned/controlled direct emissions are Scope 1; purchased electricity, steam, heating, and cooling are Scope 2; other upstream/downstream value-chain emissions are Scope 3.
- [GHG Protocol category boundaries](https://ghgptechassistance.zendesk.com/hc/en-us/articles/37916158806804-What-are-the-minimum-and-optional-boundaries-of-each-scope-3-category): a supplier's company-wide emissions cannot simply be assigned in full to each customer.
- [EcoVadis scoring principles](https://resources.ecovadis.com/ecovadis-solution-materials/csr-rating-methodology-scoring-principles): the rating assesses sustainability management through evidence, policies, actions, and results, with expert analysis. A completed questionnaire or a score is not automatically a complete, independently assured carbon inventory.

## What this evidence does not establish

No source above guarantees zero disruption, universal margin improvement, a specific Merit budget, or a universal optimum of three supplier tiers. The sources support documented mechanisms and selected outcomes. Program access, staff capacity, product licensing, supplier readiness, and costs remain separate questions for the team.
