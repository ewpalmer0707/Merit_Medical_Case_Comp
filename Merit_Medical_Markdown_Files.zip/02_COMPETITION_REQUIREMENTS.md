# Competition requirements and organizer updates

> Historical record of instructions available October 24. Prepared as a standalone Markdown file October 27. Registration and slot deadlines have passed; their completion and any later organizer updates have not been rechecked.

Recorded October 24, 2026. Source precedence: the case defines the assignment; the separate judging sheet supplies adjusted weights; the October 24 organizer email updates the earlier schedule. Times below reproduce the emails, which do not explicitly specify a time zone.

## Deliverable

Submit and present a slide deck proposing a supplier sustainability strategy that builds credible, verifiable information, strengthens supplier relationships, protects supply continuity, builds stakeholder trust, and fits Merit's values and financial commitments. A pilot must be startable in 2026; the whole global rollout need not finish in 2026.

Use public data and clearly labeled assumptions. Confidential Merit data is not expected. Exhibit 3's supplier segments and Exhibit 5's strategy comparison are illustrative composites.

The proposal must explain:

1. Which suppliers first, why, and what waits.
2. What suppliers are asked to do and what they receive in return.
3. Cost, who pays, and fit with Merit's financial targets.
4. Metrics, numerical targets, and timeline.
5. Public communication, audiences, and limits on claims.

Stakeholders: suppliers; hospitals and health systems; Board and investors; Merit associates, particularly procurement and quality. Sustainability includes environmental and social performance, worker outcomes, and business conduct, not just carbon.

## Case figures and commitments

| Item | Case figure |
|---|---|
| Suppliers | Approximately 1,030 in 42 countries |
| Concentration | Top 78 account for approximately 65% of annual spend |
| Continental U.S. supplier share | 49% |
| Qualification/requalification | 9–12 months, as stated in the case |
| Supplier audits in 2025 | 29 in Exhibit 2; see the claims register for report-level reconciliation questions |
| Growth target | 5–7% organic, constant-currency compound annual revenue growth over the program ending 2026 |
| Operating margin | 20–22% non-GAAP in 2026 |
| Free cash flow | At least $400 million cumulative over the three-year program ending December 31, 2026 |
| Direct emissions goal | 40% Scope 1+2 reduction by 2030 against 2020 |
| Vision / mission | Most customer-focused company in healthcare / Understand, Innovate, Deliver |
| HEART | Health, Excellence, Agility, Responsibility, Teamwork |

Alisha Jerauld's six-week Board deadline is part of the case scenario. It is distinct from the actual competition deadlines.

## Adjusted rubric now available in the repository

| Criterion | Weight |
|---|---:|
| Strategic rationale and fit with Merit's goals | 25% |
| Effective social impact | 25% |
| Quantitative rigor | 15% |
| Feasibility and implementation | 15% |
| Creativity and innovation | 10% |
| Professionalism and delivery | 10% |
| **Total** | **100%** |

The sheet calls for use of the Ballard Center Social Impact Cycle, measurable lasting outcomes, root-cause analysis, unintended consequences, defensible financials and peer benchmarks, a launchable pilot, and a presentation completed within ten minutes.

Source: [judging-sheet text](https://github.com/ewpalmer0707/Merit_Medical_Case_Comp/blob/main/case-materials/Judging%20Sheet.txt), with [PDF](https://github.com/ewpalmer0707/Merit_Medical_Case_Comp/blob/main/case-materials/Judging%20Sheet.pdf) retained as the original. The earlier chat's "weights unavailable" status is superseded by this repository source.

## Suggested deck structure, not a mandatory slide cap

| Section | Suggested slides |
|---|---:|
| Recommendation and rationale | 3–4 |
| Implementation and pilot | 2–3 |
| Financials and numerical metrics | 2 |
| Risks and mitigation | 1–2 |
| Communication | 1 |
| Social impact cycle | 1 |

## Organizer logistics from the October 24 email

Email subject: **ACTION NEEDED: SIGN UP SLOT FOR MERIT MEDICAL CASE COMPETITION**. Sender: Peery Business for Good, `peerybfg@byu.edu`. Read in Cameron's connected Outlook mailbox. Recipient lists and private message identifiers are intentionally omitted.

| Item | Instruction |
|---|---|
| Presentation signup | Sunday, October 25, 11:59 p.m. |
| Signup details | Put the team lead's name in an available slot under a room; fill in the requested information; add a team name. |
| Team number | The slot ID becomes the Team # for the rest of the competition and submission. |
| Check-in | TNRB first-floor atrium at least 15 minutes before your slot; then walk to the JKB. |
| Preliminary window | 9:10–11:10 a.m., JKB; ten-minute presentation and five-minute Q&A. |
| Advancement | Five teams; notification around 11:45 a.m. |
| Finals | 12:30–2:10 p.m., TNRB 710; all teams may watch. |
| Awards | 2:30 p.m. |
| Deck due | Friday, October 30, 7:00 a.m. |
| Submission | Email a PDF to `peerybfg@byu.edu`. |
| Subject | `T_Team#_TeamName_BFG` |
| PDF filename | Same basename as the email subject, with `.pdf` extension. |

[Presentation-slot signup sheet](https://docs.google.com/spreadsheets/d/13atmdhv8CHWHcaP-1DkP-eUFSeb0dF6ia_5UchZ1nuU/edit?usp=sharing)

The email says a revised judging rubric is attached and that some weights have changed. It promises further reminders and information next week.

The existing README reports a historical 11:10 a.m. slot, JKB 3106, ID 23, with missing lead/phone fields and a possible ID collision. Those details were not independently rechecked in this upload. The email's stated overall window and the sheet's last reported slot also need to be kept distinct. Neither the final team number nor a Carbon Fighters registration change is confirmed here.

## Earlier organizer email supplied by Cameron

- Case and kickoff slides were attached to that earlier email.
- Team registration was extended to Wednesday, October 21, 11:59 p.m. This is a different deadline from presentation-slot signup.
- It described 20-minute preliminary slots between 9 a.m. and noon and finals from 1:15–2:55 p.m. Those times are superseded by the later October 24 email above.
- It gave the same October 30, 7 a.m. deck deadline and organizer address.
- Prizes: first $3,000; second $2,000; third $1,000.

[Team registration sheet](https://docs.google.com/spreadsheets/d/1rUo90lYPKowr9dHDqdBNgR5W0UXRY5K_XCJyUx9_YI4/edit?usp=sharing) · [Need-a-team sheet](https://docs.google.com/spreadsheets/d/12Cj522pfdWLPY_SP8UoGO4WQ2UghaeblA22TE74UJyA/edit?usp=sharing)

## Source boundaries

The supplied PDF is already in [case-materials](https://github.com/ewpalmer0707/Merit_Medical_Case_Comp/blob/main/case-materials/Merit%20Medical%20Case.pdf). The actual organizer email attachment was inaccessible through the Outlook tools in the earlier chat, but the repo's judging sheet resolves the missing weights. This file does not establish current signup-sheet contents, a final team number, completion of registration, or submission of a deck.
