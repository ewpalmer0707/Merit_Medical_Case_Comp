# Whiteboard notes — October 24, 2026

Written record of the two photographs Cameron supplied. Handwriting is paraphrased where necessary for readability. These boards record the group's brainstorming and hypotheses, not verified company performance or an adopted strategy. The original photographs remain in Cameron's conversation; this file makes their substantive contents usable without image uploads.

## Board 1: solution options and supplier segmentation

The board is headed **Solutions** and lists two starting points:

1. Force EcoVadis participation.
2. Start with the 78 largest suppliers and defer the other approximately 900 "small fish."

A red arrow labeled **reverse** questions the second sequence. A green note says approximately **85%** could be trusted to provide real data. In the discussion, that percentage was an assumption, not a published completion or reliability rate. Also, 1,030 minus 78 is approximately **952**, rather than exactly 900.

The lower-right matrix uses these axes:

- Vertical: high impact / low impact.
- Horizontal: low readiness / high readiness.

| | Low readiness | High readiness |
|---|---|---|
| High impact | Marked with an X; the discussion focused on critical suppliers needing support. | Marked with a heart; discussed as important suppliers already capable of reporting. |
| Low impact | No clear additional annotation. | Marked with a heart; discussed as easier suppliers to engage. |

The meeting explored whether an approach that works for critical, low-readiness suppliers could later work for easier suppliers. Later conversation considered running different tracks concurrently. Neither sequencing choice was finalized.

The board's two-by-two model simplifies the case. The case also includes **moderate readiness**, and its supplier-power definition includes **sole-source status or high spend**. Supplier criticality, spend, and reporting readiness should not be assumed to be the same thing.

## Board 2: observed versus expected

The board is headed **Problem**, with **Customer focused #1** boxed across the top. Its two columns contrast what participants observed with what they hoped to achieve.

| Observed / problem framing | Expected / desired condition |
|---|---|
| Large and small suppliers are not all using EcoVadis. | Scope 3 is measurable without disrupting supply or production. |
| The request is to complete the form. | Confidence in sustainability recognition and communication. |
| The group wants real data to support the sustainability story. | Incentives to participate and maintain healthy Scope 3 performance. |
| Reporting can feel burdensome and put relationships at risk. | A process that preserves supplier relationships and continuity. |

Two statements are emphasized on the observed side: obtaining real data and avoiding disruption to supplier continuity.

## How to interpret the boards

- "Not all suppliers use EcoVadis" does not establish a precise participation rate, or prove that suppliers who do not report have poor underlying performance.
- The desired outcome is credible sustainability information and improvement. Form completion is a possible mechanism, not the final outcome.
- Maintaining operations with no burden whatsoever was an aspiration. Its feasibility was not demonstrated in the meeting.
- The case says the awards were independently earned. The missing supplier information does not itself invalidate them.
- Cost, worker outcomes, public communication, measurement, and implementation remain part of the assignment even though the boards simplify the discussion.

Read the [conversation record](01_CONVERSATION_RECORD.md) for the fuller reasoning and [claims register](04_CLAIMS_AND_OPEN_QUESTIONS.md) for evidence boundaries.
