# Merit Medical — conversation and research handoff

This records Cameron's October 24 project conversation and the research checked in that conversation. Prepared for manual upload on October 27, 2026. It preserves the team's existing recommendation and research files. It is a handoff for continued investigation, not an approved strategy or a finished presentation.

## Upload these files

Download all six `.md` files, or unzip `Merit_Medical_Markdown_Files.zip`. In the GitHub repository, use **Add file → Upload files**, select all six files, and commit the upload. Put them together in the repository root so the links between them work. The filenames are new: no existing README or team research needs to be replaced.

| File | Contents |
|---|---|
| `00_START_HERE.md` | Upload instructions, meeting status, research split, and reading order |
| `01_CONVERSATION_RECORD.md` | Edited chronological record of the project conversation |
| `02_COMPETITION_REQUIREMENTS.md` | Assignment, adjusted rubric, deadlines, and organizer logistics |
| `03_VERIFIED_BENCHMARKS.md` | Sourced findings for Philips, Medtronic, J&J, Patagonia, and Schneider |
| `04_CLAIMS_AND_OPEN_QUESTIONS.md` | Corrections, evidence limits, assumptions, and unresolved questions |
| `05_WHITEBOARD_NOTES.md` | Written record of both uploaded whiteboards |

The material records October 24 knowledge. It is not a new check of deadlines, signup status, or the team's decisions since then. Proposed strategies remain exploratory. Personal invitation details, email recipient lists, and unrelated conversation are excluded.

## Read in this order

1. [Conversation record](01_CONVERSATION_RECORD.md): the sequence of the team's reasoning, proposals, reservations, and next steps. This is an edited record, not a verbatim transcript or audio recording.
2. [Competition requirements](02_COMPETITION_REQUIREMENTS.md): case requirements, the adjusted judging weights now available in the repo, and the later organizer schedule.
3. [Benchmarks checked in Cameron's chat](03_VERIFIED_BENCHMARKS.md): Philips, Medtronic, J&J, Patagonia, and Schneider Electric, with primary-source URLs and measurement limits.
4. [Claims register](04_CLAIMS_AND_OPEN_QUESTIONS.md): verified information, meeting assumptions, and questions still needing evidence.
5. Existing deep research: [buyer programs](https://github.com/ewpalmer0707/Merit_Medical_Case_Comp/blob/main/research/analogues-buyer-programs.md), [Mexico and China](https://github.com/ewpalmer0707/Merit_Medical_Case_Comp/blob/main/research/analogues-mexico-china.md), and [outside research](https://github.com/ewpalmer0707/Merit_Medical_Case_Comp/blob/main/research/outside-research.md). Those files contain additional findings; this handoff does not independently certify all of them.

## Team position at the October 24 meeting

- The group wants to understand the problem before settling on a solution and actively look for evidence that could overturn its preferred approach.
- The central practical concern is reliable supplier sustainability information obtained without harming supplier relationships, production, or patient access. The full assignment also requires social outcomes, financial analysis, implementation, and credible communication.
- A three-track program was discussed: a light-touch track for experienced suppliers, intensive support for critical suppliers with low readiness, and a proportionate approach to the remaining suppliers. This is exploratory.
- Earlier discussion considered starting with the hardest suppliers. Later discussion considered running tracks concurrently. Neither scheduling nor resource allocation has been finalized.
- The group proposed dividing further investigation into **large suppliers / Mexico / China**. The transcript mentions relevant Mexico experience and Chinese-language ability, but does not unambiguously assign named owners. Do not infer assignments.
- The team planned to reconvene **Monday, October 26, 2026**. No time was set in the supplied conversation, and no subsequent meeting outcome is included here.
- **Carbon Fighters** was chosen conversationally as the proposed team name. The signup-sheet change is not verified. Existing repo references to Data Nerds and Team 23 are earlier records, not a new verification of the team's final registration.

## Questions carried forward from the meeting

| Workstream | Questions the group raised |
|---|---|
| Large suppliers | Is the existing EcoVadis request sufficient? Who has responded? Why have nonresponders not responded? Can an existing assessment be shared, and what evidence is still missing? |
| Mexico | What would local coaching actually involve? Are the identified programs open to medical-device suppliers? What training, eligibility, language support, cost, and capacity are documented? |
| China | Would a local consultant help, and at what cost? What does a Chinese-language platform cover? What does environmental database screening verify or fail to verify? |
| Shared financial work | Who funds assessments and coaching? What are the cash and funding effects of faster payment? What evidence supports any savings, retention, or other return? |
| Shared implementation work | Who does each task, with which tools, on what timetable? What can actually start in 2026? What would disconfirm the approach? |

These are the team's research questions, not newly adopted design requirements or promises of partner access.

## What was already in the repo when reviewed

Reviewed baseline: commit `608312f1d7537c67d165e029fd88147abd9a3ead`.

The repo already contained the case PDF and text, kickoff PowerPoint, judging PDF and text, README, problem brief, pushback checklist, strategy recommendation, three large research documents, and a source list. The top-level documents and judging-sheet text were read; the research documents were reviewed by headings and relevant sections. Their entire external source list was not re-audited.

The uploaded case PDF is byte-identical to the existing [case PDF](https://github.com/ewpalmer0707/Merit_Medical_Case_Comp/blob/main/case-materials/Merit%20Medical%20Case.pdf): Git blob SHA `037a434b31573e9a8c6d1bfe22fd6bf29ab34cda`. A duplicate was not added.

The revised rubric is now available, resolving the earlier chat limitation that the Outlook tools could not expose the email attachment. See [Judging Sheet.txt](https://github.com/ewpalmer0707/Merit_Medical_Case_Comp/blob/main/case-materials/Judging%20Sheet.txt).

## Whiteboard record

See [Whiteboard notes](05_WHITEBOARD_NOTES.md) for a written record of both uploaded boards. Photos are not required by this Markdown-only package. The notes record brainstorming, not independently verified facts.

## Scope of this archive

Included: project discussion, the organizer instructions supplied or read in this chat, factual corrections, benchmark research, written whiteboard notes, and unresolved questions. Excluded: email recipient lists, private invitation/contact details, unrelated personal conversation, hidden instructions, and unrelated prior projects. No organizer email was sent, no signup sheet was changed, and no meeting was scheduled while preparing these files. Earlier automated GitHub upload attempts failed; this package is for manual upload.
